import * as React from 'react';
import { useEffect, useState, useRef } from 'react';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import styles from './RollingText.module.scss';
import type { IRollingTextProps } from './IRollingTextProps';

const RollingText: React.FC<IRollingTextProps> = (props) => {
  const [items, setItems] = useState<string[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  // Fetch list items using SPHttpClient
  useEffect(() => {
    if (!props.listId || !props.context) {
      setItems([]);
      return;
    }

    const fetchItems = async () => {
      try {
        const listIdStr = String(props.listId).replace(/\{|\}/g, '');
        const field = props.listContent || 'Title';
        
        // Use relative URL starting with /_api - SPHttpClient resolves this correctly
        const apiUrl = `/_api/web/lists(guid'${listIdStr}')/items?$select=${field}`;
        
        const response: SPHttpClientResponse = await props.context.spHttpClient.get(
          apiUrl,
          SPHttpClient.configurations.v1,
          {
            headers: {
              'Accept': 'application/json;odata=nometadata'
            }
          }
        );

        if (!response.ok) {
          console.error(`Failed to fetch items: ${response.status} ${response.statusText}`);
          setItems([]);
          return;
        }

        const json = await response.json();
        const fetchedItems = (json.value || [])
          .map((item:any) => String(item[field] || '').trim())
          .filter((item: any) => item.length > 0);
        
        setItems(fetchedItems);
      } catch (error) {
        console.error('Error fetching list items:', error);
        setItems([]);
      }
    };

    fetchItems();
  }, [props.listId, props.listContent, props.context]);

  // Animation effect
  useEffect(() => {
    const container = containerRef.current;
    const content = contentRef.current;
    if (!container || !content || items.length === 0) return;

    let animationId: number;
    let lastTime = performance.now();
    let offset = 0;
    let isPaused = false;

    const handleMouseEnter = () => {
      if (props.pauseOnHover) isPaused = true;
    };

    const handleMouseLeave = () => {
      if (props.pauseOnHover) {
        isPaused = false;
        lastTime = performance.now();
      }
    };

    container.addEventListener('mouseenter', handleMouseEnter);
    container.addEventListener('mouseleave', handleMouseLeave);

    const animate = (currentTime: number) => {
      const rect = content.getBoundingClientRect();
      const contentWidth = rect.width / 2;
      const speedSeconds = props.speedSeconds > 0 ? props.speedSeconds : 8;
      const speed = contentWidth / (speedSeconds * 1000);
      const deltaTime = currentTime - lastTime;
      lastTime = currentTime;

      if (!isPaused && contentWidth > 0) {
        offset = (offset + speed * deltaTime) % contentWidth;
        content.style.transform = `translateX(${-offset}px)`;
      }

      animationId = requestAnimationFrame(animate);
    };

    animationId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animationId);
      container.removeEventListener('mouseenter', handleMouseEnter);
      container.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [items, props.speedSeconds, props.pauseOnHover]);

  const textColor = props.textColor || '#000000';

  return (
    <div className={styles.rollingText} ref={containerRef} style={{ overflow: 'hidden' }}>
      <div
        className={styles.container}
        ref={contentRef}
        style={{ display: 'inline-flex', whiteSpace: 'nowrap', willChange: 'transform' }}
      >
        {[0, 1].map((rep) => (
          <div key={rep} aria-hidden={rep === 1} style={{ display: 'inline-flex' }}>
            {items.map((item, i) => (
              <span key={`${rep}-${i}`} style={{ marginRight: '0.5rem', color: textColor }}>
                {item}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default RollingText;