
require("./RollingText.module.css");
const styles = {
  rollingText: 'rollingText_3617b635',
  container: 'container_3617b635',
  track: 'track_3617b635',
  'scroll-left': 'scroll-left_3617b635',
  group: 'group_3617b635',
  item: 'item_3617b635',
  pauseOnHover: 'pauseOnHover_3617b635',
  welcome: 'welcome_3617b635',
  links: 'links_3617b635'
};

export default styles;
