
require("./RollingText.module.css");
const styles = {
  rollingText: 'rollingText_f05810dc',
  pauseOnHover: 'pauseOnHover_f05810dc',
  track: 'track_f05810dc',
  placeholder: 'placeholder_f05810dc',
  error: 'error_f05810dc',
  viewport: 'viewport_f05810dc',
  'rt-scroll': 'rt-scroll_f05810dc',
  item: 'item_f05810dc'
};

export default styles;
